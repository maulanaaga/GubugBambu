<?php
        
        require_once './koneksi.php';


        $idPengguna = $_POST['idPengguna'];
        $namaFoto = $_POST['namaFoto'];
        $tanggal = $_POST['tanggal'];
        $namatoko = $_POST['namatoko'];
        $hargasewa = $_POST['hargasewa'];
        $deskripsi = $_POST['deskripsi'];

        $sql = "INSERT INTO uploadfototemp(idPengguna,namaFoto,tanggal,namatoko,hargasewa,deskripsi) VALUES('$idPengguna','$namaFoto','$tanggal','$namatoko','$hargasewa','$deskripsi')";
        
        if($db->query($sql)==TRUE){
            $hasil['kode']=1;
            $hasil['pesan']="foto berhasil di tambahkan";
        }else{
            $hasil['kode']=0;
            $hasil['pesan']="foto gagal di tambahkan";
        }

        echo json_encode($hasil);

?>