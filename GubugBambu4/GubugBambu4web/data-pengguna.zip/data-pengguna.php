<?php
    require_once 'koneksi.php';
    
    $email = $_POST['email'];
      //$email="pobi@gmail.com";
    $password = md5($_POST['password']);
      //$password="d2ffb3dbda9ed125c5c6e804d8beb777";
    
    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password' LIMIT 1";
    $hasil = $db->query($sql);
    if($hasil->num_rows > 0){
        $baris = $hasil->fetch_assoc();
        $hasilCetak['id'] = $baris['id'];
        $hasilCetak['username'] = $baris['username'];
        $hasilCetak['fullname'] = $baris['fullname'];

    }else{
         $hasilCetak['id'] = '';
        $hasilCetak['username'] = '';
        $hasilCetak['fullname'] = '';      
    }
   
    echo json_encode($hasilCetak);
?>